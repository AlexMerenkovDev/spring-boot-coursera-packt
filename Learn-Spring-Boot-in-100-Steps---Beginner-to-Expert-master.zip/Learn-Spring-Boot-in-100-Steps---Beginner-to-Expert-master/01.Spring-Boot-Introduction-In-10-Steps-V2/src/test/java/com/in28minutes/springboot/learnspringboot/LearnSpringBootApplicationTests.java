package com.in28minutes.springboot.learnspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
